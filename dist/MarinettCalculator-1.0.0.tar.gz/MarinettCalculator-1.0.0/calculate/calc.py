__all__ = ['calculate', 'convert_precision', 'InputOp', 'InputAct', 'main', 'div', 'minus', 'sum', 'mulp', 'pow', 'remaind', 'std_dev', 'PARAMS', 'load_params']


import math
import numpy as np
from typing import Union
from .calcprint import PARAMS, load_params


def convert_precision(precision='0.001') -> int:
  """
    Конвертирование точности вычислений
  """
  if type(precision) is str:
    try:
      precision = float(precision)
      return int(math.fabs(math.log10(precision)))
    except ValueError:
      print('Ошибка в значении точности')
      print('Используется значение по умолчанию {0.00001}')
      precision = 0.00001
      return int(math.fabs(math.log10(precision)))


def InputOp():
  """
    Функция ввода и проверки операндов 
  """
  operands = []
  op = 1
  while op != "":  # while True
    op = input("Введите операнд: ")
    try:
      if op == "":
        break
      op = float(op)
    except (ValueError, TypeError):
      print('Ошибка типа данных, введите новый операнд!')
    else:
      op = float(op)
      operands.append(op)
  return operands


def InputAct():
  """
    Функция ввода и проверки действия 
  """
  while True:
    action = input('Введите действие для вычисления: ')
    if action in ['+', '-', '*', '/', '**', '%', 'std_dev']:
      return action
    else:
      print(
        "Ошибка! Введенное действие некорректно! Выберите действие из предложеннных +, -, *, /, **, %, std_dev"
      )
      continue
  pass


def main():
  """
    Основная запускающая функция
  """
  global PARAMS
  load_params('params.ini')
  operands = []

  while True:
    operands = InputOp()

    action = InputAct()

    res = calculate(operands, action, PARAMS)
    if res == None:
      print('Неверные значения, введите данные заново')
      continue
    print_results(operands, action, res)
    write_log(operands, action, res, PARAMS)
    break


def div(*args: Union[tuple, list]) -> float:
  """
    Функция деления операндов
  """
  res = args[0]
  if 0 in args[1:]:
    return
  for _el in args[1:]:
    res /= _el
  return res


def minus(*args: Union[tuple, list]) -> Union[int, float]:
  """
    Функция вычитания операндов
  """
  res = args[0]
  for _el in args[1:]:
    res -= _el
  return res


def sum(*args: Union[tuple, list]) -> Union[int, float]:
  """
    Функция сложения операндов
  """
  res = args[0]
  for _el in args[1:]:
    res += _el
  return res


def mulp(*args: Union[tuple, list]) -> Union[int, float]:
  """
    Функция умножения операндов
  """
  res = args[0]
  for _el in args[1:]:
    res *= _el
  return res


def pow(*args: Union[tuple, list]) -> Union[int, float]:
  """
    Функция возведения в степень операндов
  """
  res = args[0]
  for _el in args[1:]:
    res **= _el
  return res


def remaind(*args: Union[tuple, list]) -> Union[int, float]:
  """
    Функция нахождения остатка от деления
  """
  res = args[0]
  for _el in args[1:]:
    res %= _el
  return res


def std_dev(*args: Union[tuple, list]) -> float:
  """
    Функция вычисление среднего квадратического отклонения
  """
  args = np.array(args)
  res = np.std(args)

  return res



def calculate(operands: list, action, params=PARAMS):
  """
    Основная вычислительная функция   
  """
  load_params('params.ini')

  operation = None
  
  if action == '+':
    operation = sum(*operands)
  elif action == '-':
    operation = minus(*operands)
  elif action == '/':
    operation = div(*operands)
  elif action == '*':
    operation = mulp(*operands)
  elif action == '**':
    operation = pow(*operands)
  elif action == '%':
    operation = remaind(*operands)
  elif action == 'std_dev':
    operation = std_dev(*operands)

  if operation == None:
    return

  output_type = params.get('output_type')
  precision = params.get('precision')
  #print(convert_precision(str(precision)))

  return round(output_type(operation), convert_precision(str(precision)))


if __name__ == '__main__':
    main()
