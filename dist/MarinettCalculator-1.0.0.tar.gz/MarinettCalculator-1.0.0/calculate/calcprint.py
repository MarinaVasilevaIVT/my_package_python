__all__ = ['load_params','calculate_file']

import configparser

PARAMS = {
  'precision': None,
  'output_type': None,
  'possible_types': None,
  'dest': None
}


def load_params(file):
  """
    Функция, загружающая параметры из файла конфигурации

    """
  global PARAMS

  config = configparser.ConfigParser()
  config.read(file)

  if 'DEFAULT' in config:
    if 'precision' in config['DEFAULT']:
      PARAMS['precision'] = config.getfloat('DEFAULT', 'precision')

    if 'output_type' in config['DEFAULT']:
      output_type = config.get('DEFAULT', 'output_type')
      PARAMS['output_type'] = float if output_type == 'float' else int

    if 'possible_types' in config['DEFAULT']:
      possible_types = config.get('DEFAULT', 'possible_types')
      types = tuple(t.strip() for t in possible_types.split(',') if t.strip())
      PARAMS['possible_types'] = types

    if 'dest' in config['DEFAULT']:
      PARAMS['dest'] = config.get('DEFAULT', 'dest')


def print_results(operands: list, action: str, result):
  """
    Вывод в табличном виде результатов вычислений

    Функция принимает переменное число значений, которые нужно вывести в табличном виде. 
    последний аргумент в упакованном кортеже - результат вычислений, 
    предпоследний - действие, которое выполнилось,остальные — аргументы, с которыми это действие выполнилось.
    """

  table_body = "| "
  for op in operands:
    table_body += str(op) + ", "

  table_body = table_body.rstrip(', ')
  table_body += " | "

  table_header_len = len(table_body)

  table_body += str(action) + " | "

  table_body += str(result) + " |"

  print("-" * len(table_body))
  print('operands'.center(table_header_len), end=" | ")
  print('result'.center(len(str(result + 2))))

  print("-" * len(table_body))
  print(table_body)
  print("-" * len(table_body))


def write_log(*args, action=None, result=None, file='calc-history.log.txt'):
  """
    Функция записи результатов вычислений в лог-файл

  """
  from datetime import date
  today = date.today()
  date = str(today.strftime('%d-%m-%y'))

  f = open(file, mode='a', errors='ignore')

  f.write(f"Новая строка {date}: {action}: {args} = {result} \n")
  f.close()

def calculate_file(*args, **kwargs):

  load_params('params.ini')

  res = sum(args)

  try:
      write_log(*args, action='sum', result=res, file=PARAMS['dest'])
  except Exception as e:
      action = 'sum'
      print(e)
      print(f"{action}: {args} = {res}")