__all__ = ['TestCalculate']

from .calc import calculate
import unittest


class TestCalculate(unittest.TestCase):

  def test_sum(self):
    self.assertEqual(calculate([1234, 250000], '+'), 251234)

  def test_minus(self):
    self.assertEqual(calculate([150, 200], '-'), -50)

  def test_multiply_1(self):
    self.assertEqual(calculate([85, 0], '*'), 0)

  def test_multiply_2(self):
    self.assertEqual(calculate([85, -1], '*'), -85)

  def test_division_1(self):
    self.assertIsNone(calculate([1, 0], '/'))

  def test_division_2(self):
    self.assertEqual(calculate([1, 3], '/'), 0.333333)

  def test_power(self):
    self.assertEqual(calculate([2, 8], '**'), 256)

  def test_remainder(self):
    self.assertEqual(calculate([1876, 55], '%'), 6)

  def test_std_dev_1(self):
    self.assertEqual(calculate([1, 1, 1], 'std_dev'), 0.0)

  def test_std_dev_2(self):
    self.assertEqual(calculate([12, 13, 14, 15], 'std_dev'), 1.118034)


if __name__ == '__main__':
  unittest.main()
